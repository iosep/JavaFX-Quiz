package projekt;

import javafx.application.Application;

/**
 * Start-Klasse. Hat die Aufgabe die JavaFX-Anwendung zu starten.
 */
class Start {
    public static void main(String[] args) {
        Application.launch(MainApplication.class, args);
    }
}
