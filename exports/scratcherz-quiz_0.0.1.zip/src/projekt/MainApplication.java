package projekt;

import javafx.application.Application;
import javafx.stage.Stage;
import projekt.controller.ScreenController;

/**
 * Klasse, die die JavaFX-Anwendung bereitstellt.
 */
public class MainApplication extends Application {
    // Globale Konfigurationsparameter
    public static final String TITLE = "Scratcherz";

    /**
     * Startet die JavaFX Anwendung.
     *
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        ScreenController.setPrimaryStage(primaryStage);
        ScreenController.showLoginView();
    }
}
