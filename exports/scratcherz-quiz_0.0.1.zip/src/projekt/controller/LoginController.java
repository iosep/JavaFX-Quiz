package projekt.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Klasse zum Erstellen des LoginControllers
 */
public class LoginController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField playerNameTextField;

    @FXML
    private ImageView playerImgView;

    @FXML
    private Button loginButton;

    /**
     * Dient zum Auswählen des vorherigen Avatares.
     *
     * @param event Event mit der die Methode aufgerufen wird.
     */
    @FXML
    void prevImageHandler(ActionEvent event) {

    }

    /**
     * Dient zum Auswählen des nächsten Avatares.
     *
     * @param event Event mit der die Methode aufgerufen wird.
     */
    @FXML
    void nextImageHandler(ActionEvent event) {

    }

    /**
     * Leitet den Login ein.
     *
     * @param event Event mit der die Methode aufgerufen wird.
     */
    @FXML
    void loginHandler(ActionEvent event) {

    }

    @FXML
    void initialize() {
        assert playerNameTextField != null : "fx:id=\"playerNameTextField\" was not injected: check your FXML file 'LoginScreen.fxml'.";
        assert playerImgView != null : "fx:id=\"playerImgView\" was not injected: check your FXML file 'LoginScreen.fxml'.";
        assert loginButton != null : "fx:id=\"loginButton\" was not injected: check your FXML file 'LoginScreen.fxml'.";

    }
}
