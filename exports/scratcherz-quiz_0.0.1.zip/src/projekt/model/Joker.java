package projekt.model;

/**
 * Enthält Name, Bild und Funktion eines Jokers.
 */
public class Joker {
}
