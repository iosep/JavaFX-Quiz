package projekt;

import javafx.application.Application;

/**
 * Klasse, die zum Starten der JavaFX-Anwendung dient.
 */
public class Start {

    /**
     * Main Methode. Startet die JavaFX-Anwendung.
     *
     * @param args Startparameter.
     */
    public static void main(String[] args) {
        Application.launch(MainApplication.class, args);
    }
}
